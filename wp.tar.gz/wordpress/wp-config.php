<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, and ABSPATH. You can find more information by visiting
 * {@link https://codex.wordpress.org/Editing_wp-config.php Editing wp-config.php}
 * Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'wordpress');

/** MySQL database username */
define('DB_USER', 'wordpress');

/** MySQL database password */
define('DB_PASSWORD', 'wordpress');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'h7*dQ@)~_P-`aidea|j+I<1gZ,D5[8/WqVBy#8)m<?8O-ZuK iry<j;R0gxt!sW1');
define('SECURE_AUTH_KEY',  'v($&^O9fjZ:OpG5H)LThH]YPxf!%@Bmk#Bg2G3zPJ-z[9X0xGF(35[(+-$=kI(k$');
define('LOGGED_IN_KEY',    '`GNF0JYLVq}*CW;0j=*qtbf9,!Z8?~Sa@^mb!3Oemo<z73UBe_Dyb~B+e[ Cx`tF');
define('NONCE_KEY',        '1KcCGl&ucT??LJ(y{ljDqN>%yc~fE8bN%N/1* 6jhLnQ3a3A$I6|DO:@&g+.to*k');
define('AUTH_SALT',        'bnL!@^I5Wx#.Y:~gmQ<Z?T(Wq+skGo2_GfJ95}+dS7T@}vp2X;8dYitFi;^Xft2<');
define('SECURE_AUTH_SALT', '5qWun;XH4:w%l).:Za0ToLo0~]TbPB=?pFSu^L`lhUsHw3k;AM]#<PNbklPMt7z!');
define('LOGGED_IN_SALT',   'z]uRSErE)SnTMw@s X1j!wuKHw<JvgelQlrF_:O*|{57}E/+*LOc`l#mbBl?>2YA');
define('NONCE_SALT',       'P@x[ E8$.69HQKH[+:]YKjyd$`uDM7WnBH (D1/>cekUb`s-|wK4HeVO[Jvdu#t~');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');

